package com.cts.training.userservice.model;

import java.util.List;

import com.cts.training.userservice.entity.Users;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataModel {
	
	public List<Users> users; 

}

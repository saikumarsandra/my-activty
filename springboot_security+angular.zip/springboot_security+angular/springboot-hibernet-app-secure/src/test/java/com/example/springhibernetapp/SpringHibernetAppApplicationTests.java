package com.example.springhibernetapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHibernetAppApplicationTests {

	@Test
	void contextLoads() {
	}

}

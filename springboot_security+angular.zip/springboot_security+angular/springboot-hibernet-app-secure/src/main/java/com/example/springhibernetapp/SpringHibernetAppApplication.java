package com.example.springhibernetapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringHibernetAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringHibernetAppApplication.class, args);
	}

}
